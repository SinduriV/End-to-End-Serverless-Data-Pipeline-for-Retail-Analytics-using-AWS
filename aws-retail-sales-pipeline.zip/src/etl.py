import pandas as pd
import os

def read_raw_data(file_path):
    try:
        data = pd.read_csv(file_path)
        print("Raw data read successfully.")
        return data
    except Exception as e:
        print("Error reading data:", e)
        return None

def transform_data(df):
    df['date'] = pd.to_datetime(df['date'])
    df['month'] = df['date'].dt.to_period('M')
    df = df.dropna()
    print("Data transformation completed.")
    return df

def write_transformed_data(df, output_file):
    try:
        df.to_csv(output_file, index=False)
        print(f"Transformed data written to {output_file}")
    except Exception as e:
        print("Error writing data:", e)

def main():
    input_file = os.path.join("..", "data", "retail_sales.csv")
    output_file = os.path.join("..", "data", "retail_sales_transformed.csv")
    raw_data = read_raw_data(input_file)
    if raw_data is not None:
        transformed_data = transform_data(raw_data)
        write_transformed_data(transformed_data, output_file)

if __name__ == "__main__":
    main()
