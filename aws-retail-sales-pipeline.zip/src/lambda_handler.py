import json
import pandas as pd

def lambda_handler(event, context):
    file_path = '/tmp/retail_sales.csv'
    try:
        df = pd.read_csv(file_path)
        df['date'] = pd.to_datetime(df['date'])
        df['month'] = df['date'].dt.to_period('M')
        print("Transformed Data:")
        print(df.head())
        return {
            'statusCode': 200,
            'body': json.dumps('ETL process completed successfully!')
        }
    except Exception as e:
        print("Error in Lambda ETL process:", e)
        return {
            'statusCode': 500,
            'body': json.dumps('ETL process failed!')
        }
